package com.jugueteria.api.dto.response;

import lombok.Data;

@Data
public class CategoryResponse {
    private Long id;
    private String nombre;
}